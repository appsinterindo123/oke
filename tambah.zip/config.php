<?php 
mysqli_connect('localhost', 'root', 'root', 'cillco');
//mysqli_select_db('mahasiswa');
$con = mysqli_connect('localhost', 'root', 'root', 'cillco');
?>