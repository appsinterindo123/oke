<?php
require_once "controller.php";
$con=new controller();
if($_POST['text']!==""){
  $con->proses($_POST['text']);
}

require_once "controller2.php";
$con2=new controller();
if($_POST['text2']!==""){
  $con2->proses($_POST['text2']);
}

//require_once "hasil.php";

?>
