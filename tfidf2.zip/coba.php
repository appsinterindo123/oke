<?php
$text = "  Baris pertama  
Baris kedua  
  Baris ketiga  ";
  echo $text;
  $str = preg_replace('/^\h*\v+/m', '', $text);

  echo $str;
?>