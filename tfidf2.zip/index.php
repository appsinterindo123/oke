<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<style media="screen">
  h2{
    text-align: center;
  }

  .text{
    width: 75%;
    margin: auto;
  }
  .hasil{
    width: 75%;
  margin: auto;
  }
  .hasil h2{
    text-align: center2
  }
  .text button{
    display: block;
    margin-left: auto;
    margin-right: auto;
    margin-top: 10px;
  }
  textarea{
    resize: none;
  }
</style>
  </head>
  <body>
    <form class="" action="action.php" method="post">
      <h2>Text Processing TF-IDF</h2>
      <div class="text">
            <textarea class="form-control" name="text" rows="10" cols="80"></textarea>
            <textarea class="form-control" name="text2" rows="10" cols="80"></textarea>
            <button class="btn btn-primary" type="submit" name="button">Proses Text</button>
      </div>


    </form>




  </body>
</html>

<?php

?>
